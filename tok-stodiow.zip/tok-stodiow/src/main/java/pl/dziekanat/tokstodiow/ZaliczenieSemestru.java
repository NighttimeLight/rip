package pl.dziekanat.tokstodiow;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("Sklep z mundurami i karabinami App")
public class ZaliczenieSemestru extends ServletProcessApplication {

}


